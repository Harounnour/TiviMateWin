namespace TiviMateWin;

public enum Kind { Live, Movie, Series, Sport }
public enum SourceType { M3U, Xtream, Stalker }

public class PlaylistSource
{
    public string Name { get; set; } = "";
    public SourceType Type { get; set; }
    public string Url { get; set; } = "";   // URL/fichier M3U, serveur Xtream, ou portail Stalker
    public string User { get; set; } = "";
    public string Pass { get; set; } = "";
    public string Mac { get; set; } = "";
    public override string ToString() => $"{Name} ({Type})";
}

public class Channel
{
    public string Name = "";
    public string Group = "Autres";
    public string Url = "";
    public string? Logo;
    public Kind Kind;
    public string? Cmd;       // Stalker
    public string? SeriesId;  // Xtream séries
    public override string ToString() => Name;
}
