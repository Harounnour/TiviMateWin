using System.Net.Http;
using System.Text.Json;
namespace TiviMateWin;

// Portail Stalker / Ministra (MAG) : chaînes en direct.
public class StalkerClient
{
    readonly HttpClient http = new() { Timeout = TimeSpan.FromMinutes(5) };
    readonly string load, mac;
    string token = "";

    public StalkerClient(PlaylistSource s)
    {
        var u = s.Url.TrimEnd('/');
        if (u.EndsWith("/c", StringComparison.OrdinalIgnoreCase)) u = u[..^2];
        load = u.EndsWith(".php", StringComparison.OrdinalIgnoreCase) ? u : u + "/server/load.php";
        mac = s.Mac.Trim();
    }

    static string Str(JsonElement e, string n)
    {
        if (!e.TryGetProperty(n, out var v)) return "";
        return v.ValueKind switch { JsonValueKind.String => v.GetString() ?? "", JsonValueKind.Null => "", _ => v.ToString() };
    }

    async Task<JsonElement> Q(string query)
    {
        using var req = new HttpRequestMessage(HttpMethod.Get, $"{load}?{query}&JsHttpRequest=1-xml");
        req.Headers.TryAddWithoutValidation("Cookie", $"mac={mac}; stb_lang=en; timezone=GMT");
        req.Headers.UserAgent.ParseAdd("Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3");
        req.Headers.TryAddWithoutValidation("X-User-Agent", "Model: MAG250; Link: WiFi");
        if (token != "") req.Headers.TryAddWithoutValidation("Authorization", "Bearer " + token);
        using var resp = await http.SendAsync(req);
        resp.EnsureSuccessStatusCode();
        using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync());
        return doc.RootElement.GetProperty("js").Clone();
    }

    public async Task<List<Channel>> LoadAsync(IProgress<string> p)
    {
        p.Report("Stalker : connexion au portail…");
        var hs = await Q("type=stb&action=handshake&token=");
        token = Str(hs, "token");
        try { await Q("type=stb&action=get_profile"); } catch { }

        var genres = new Dictionary<string, string>();
        try { foreach (var e in (await Q("type=itv&action=get_genres")).EnumerateArray()) genres[Str(e, "id")] = Str(e, "title"); } catch { }

        p.Report("Stalker : chargement des chaînes…");
        var all = await Q("type=itv&action=get_all_channels");
        var list = new List<Channel>();
        foreach (var e in all.GetProperty("data").EnumerateArray())
            list.Add(new Channel
            {
                Name = Str(e, "name"), Logo = Str(e, "logo"), Cmd = Str(e, "cmd"),
                Group = genres.GetValueOrDefault(Str(e, "tv_genre_id"), "Autres"), Kind = Kind.Live
            });
        return list;
    }

    public async Task<string> ResolveAsync(string cmd)
    {
        try
        {
            var r = await Q("type=itv&action=create_link&cmd=" + Uri.EscapeDataString(cmd));
            cmd = Str(r, "cmd");
        }
        catch { }
        int sp = cmd.IndexOf(' ');
        return sp >= 0 ? cmd[(sp + 1)..] : cmd;
    }
}
