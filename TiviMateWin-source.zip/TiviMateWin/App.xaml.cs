using System.Windows;
namespace TiviMateWin;
public partial class App : Application { }
