using System.Windows;

namespace TiviMateWin;

public partial class SettingsWindow : Window
{
    readonly AppSettings s;
    public SettingsWindow(AppSettings settings)
    {
        InitializeComponent();
        s = settings;
        BgBox.Text = s.Background ?? "";
        CacheBox.Text = s.CachingMs.ToString();
    }

    void Pick_Click(object sender, RoutedEventArgs e)
    {
        var d = new Microsoft.Win32.OpenFileDialog { Filter = "Images|*.jpg;*.jpeg;*.png;*.bmp" };
        if (d.ShowDialog() == true) BgBox.Text = d.FileName;
    }

    void ResetBg_Click(object sender, RoutedEventArgs e) => BgBox.Text = "";

    void ClearCache_Click(object sender, RoutedEventArgs e)
    {
        try { if (Directory.Exists(AppSettings.CacheDir)) Directory.Delete(AppSettings.CacheDir, true); MessageBox.Show("Cache vidé."); }
        catch (Exception ex) { MessageBox.Show(ex.Message); }
    }

    void Save_Click(object sender, RoutedEventArgs e)
    {
        s.Background = string.IsNullOrWhiteSpace(BgBox.Text) ? null : BgBox.Text;
        if (int.TryParse(CacheBox.Text, out var ms) && ms >= 300) s.CachingMs = ms;
        s.Save();
        DialogResult = true;
    }
}
