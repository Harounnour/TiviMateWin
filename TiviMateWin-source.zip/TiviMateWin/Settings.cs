using System.Text.Json;
namespace TiviMateWin;

public class AppSettings
{
    public List<PlaylistSource> Sources { get; set; } = new();
    public int Active { get; set; } = -1;
    public string? Background { get; set; }
    public int CachingMs { get; set; } = 3000;

    static string Dir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "TiviMateWin");
    public static string CacheDir => Path.Combine(Dir, "cache");
    static string FilePath => Path.Combine(Dir, "settings.json");

    public PlaylistSource? ActiveSource => Active >= 0 && Active < Sources.Count ? Sources[Active] : null;

    public static AppSettings Load()
    {
        try { if (System.IO.File.Exists(FilePath)) return JsonSerializer.Deserialize<AppSettings>(System.IO.File.ReadAllText(FilePath)) ?? new(); }
        catch { }
        return new();
    }

    public void Save()
    {
        Directory.CreateDirectory(Dir);
        System.IO.File.WriteAllText(FilePath, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
    }
}
