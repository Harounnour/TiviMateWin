# TiviMate Win — lecteur IPTV pour Windows

Lecteur IPTV Windows (WPF, .NET 8) inspiré de TiviMate : écran d'accueil avec image de fond,
En direct / Films / Séries / Sports, Paramètres, Recharger le portail, Sortie.

- Sources : M3U (URL ou fichier), Xtream Codes, Stalker/Ministra (direct)
- Playlists > 200 Mo : téléchargement en flux vers un cache disque + lecture ligne par ligne
- Lecteur intégré : LibVLC (équivalent Windows d'ExoPlayer, qui n'existe que sous Android)
- Image de fond : Paramètres > Choisir, ou placer `background.jpg` à côté du .exe

## Compiler
Localement : `dotnet publish -c Release -r win-x64 --self-contained true -o out`
Ou via GitHub : pousser sur `main`, onglet Actions > "Build Windows EXE" > télécharger l'artefact `TiviMateWin-win-x64`.
L'exécutable est `TiviMateWin.exe` (garder le dossier complet, il contient libvlc).

Raccourcis : F11 plein écran, Échap retour, Espace pause, Entrée/double-clic pour lire.
