using System.Windows;
using System.Windows.Controls;

namespace TiviMateWin;

public partial class PlaylistWindow : Window
{
    readonly AppSettings s;
    public bool Changed;

    public PlaylistWindow(AppSettings settings)
    {
        InitializeComponent();
        s = settings;
        TypeBox.ItemsSource = Enum.GetValues<SourceType>();
        TypeBox.SelectedIndex = 0;
        Refresh();
    }

    void Refresh()
    {
        SourceList.ItemsSource = null;
        SourceList.ItemsSource = s.Sources;
        if (s.Active >= 0 && s.Active < s.Sources.Count) SourceList.SelectedIndex = s.Active;
    }

    void Type_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (XtreamPanel == null || MacPanel == null) return;
        var t = (SourceType)TypeBox.SelectedItem;
        XtreamPanel.Visibility = t == SourceType.Xtream ? Visibility.Visible : Visibility.Collapsed;
        MacPanel.Visibility = t == SourceType.Stalker ? Visibility.Visible : Visibility.Collapsed;
        UrlLabel.Text = t switch { SourceType.M3U => "URL M3U ou chemin du fichier", SourceType.Xtream => "Serveur (http://host:port)", _ => "Portail (http://host/c/)" };
    }

    void Browse_Click(object sender, RoutedEventArgs e)
    {
        var d = new Microsoft.Win32.OpenFileDialog { Filter = "Playlists (*.m3u;*.m3u8)|*.m3u;*.m3u8|Tous|*.*" };
        if (d.ShowDialog() == true) UrlBox.Text = d.FileName;
    }

    void Add_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(UrlBox.Text)) return;
        s.Sources.Add(new PlaylistSource
        {
            Name = string.IsNullOrWhiteSpace(NameBox.Text) ? "Liste " + (s.Sources.Count + 1) : NameBox.Text.Trim(),
            Type = (SourceType)TypeBox.SelectedItem,
            Url = UrlBox.Text.Trim(), User = UserBox.Text.Trim(), Pass = PassBox.Text.Trim(), Mac = MacBox.Text.Trim()
        });
        s.Active = s.Sources.Count - 1;
        s.Save(); Changed = true; DialogResult = true;
    }

    void Use_Click(object sender, RoutedEventArgs e)
    {
        if (SourceList.SelectedIndex < 0) return;
        s.Active = SourceList.SelectedIndex;
        s.Save(); Changed = true; DialogResult = true;
    }

    void Del_Click(object sender, RoutedEventArgs e)
    {
        int i = SourceList.SelectedIndex;
        if (i < 0) return;
        s.Sources.RemoveAt(i);
        if (s.Active == i) s.Active = s.Sources.Count > 0 ? 0 : -1; else if (s.Active > i) s.Active--;
        s.Save(); Changed = true; Refresh();
    }
}
