using System.Net.Http;
using System.Text.Json;
namespace TiviMateWin;

public static class XtreamClient
{
    static readonly HttpClient Http = new() { Timeout = TimeSpan.FromMinutes(10) };

    static string Api(PlaylistSource s, string action, string extra = "") =>
        $"{s.Url.TrimEnd('/')}/player_api.php?username={Uri.EscapeDataString(s.User)}&password={Uri.EscapeDataString(s.Pass)}&action={action}{extra}";

    static async Task<JsonDocument> GetAsync(string url)
    {
        using var req = new HttpRequestMessage(HttpMethod.Get, url);
        req.Headers.UserAgent.ParseAdd("VLC/3.0.20 LibVLC/3.0.20");
        using var resp = await Http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead);
        resp.EnsureSuccessStatusCode();
        await using var st = await resp.Content.ReadAsStreamAsync();
        return await JsonDocument.ParseAsync(st);
    }

    static string S(JsonElement e, string n)
    {
        if (!e.TryGetProperty(n, out var v)) return "";
        return v.ValueKind switch { JsonValueKind.String => v.GetString() ?? "", JsonValueKind.Null => "", _ => v.ToString() };
    }

    static async Task<Dictionary<string, string>> Cats(PlaylistSource s, string action)
    {
        var d = new Dictionary<string, string>();
        try
        {
            using var doc = await GetAsync(Api(s, action));
            foreach (var e in doc.RootElement.EnumerateArray()) d[S(e, "category_id")] = S(e, "category_name");
        }
        catch { }
        return d;
    }

    public static async Task<List<Channel>> LoadAsync(PlaylistSource s, IProgress<string> p)
    {
        var b = s.Url.TrimEnd('/');
        var list = new List<Channel>();

        p.Report("Xtream : chaînes en direct…");
        var lc = await Cats(s, "get_live_categories");
        using (var doc = await GetAsync(Api(s, "get_live_streams")))
            foreach (var e in doc.RootElement.EnumerateArray())
            {
                var g = lc.GetValueOrDefault(S(e, "category_id"), "Autres");
                list.Add(new Channel
                {
                    Name = S(e, "name"), Group = g, Logo = S(e, "stream_icon"),
                    Url = $"{b}/live/{s.User}/{s.Pass}/{S(e, "stream_id")}.ts",
                    Kind = g.Contains("sport", StringComparison.OrdinalIgnoreCase) ? Kind.Sport : Kind.Live
                });
            }

        try
        {
            p.Report("Xtream : films…");
            var vc = await Cats(s, "get_vod_categories");
            using var doc = await GetAsync(Api(s, "get_vod_streams"));
            foreach (var e in doc.RootElement.EnumerateArray())
            {
                var ext = S(e, "container_extension"); if (ext == "") ext = "mp4";
                list.Add(new Channel
                {
                    Name = S(e, "name"), Group = vc.GetValueOrDefault(S(e, "category_id"), "Autres"), Logo = S(e, "stream_icon"),
                    Url = $"{b}/movie/{s.User}/{s.Pass}/{S(e, "stream_id")}.{ext}", Kind = Kind.Movie
                });
            }
        }
        catch { }

        try
        {
            p.Report("Xtream : séries…");
            var sc = await Cats(s, "get_series_categories");
            using var doc = await GetAsync(Api(s, "get_series"));
            foreach (var e in doc.RootElement.EnumerateArray())
                list.Add(new Channel
                {
                    Name = S(e, "name"), Group = sc.GetValueOrDefault(S(e, "category_id"), "Autres"), Logo = S(e, "cover"),
                    SeriesId = S(e, "series_id"), Kind = Kind.Series
                });
        }
        catch { }
        return list;
    }

    public static async Task<List<Channel>> EpisodesAsync(PlaylistSource s, string seriesId)
    {
        var b = s.Url.TrimEnd('/');
        var res = new List<Channel>();
        using var doc = await GetAsync(Api(s, "get_series_info", $"&series_id={seriesId}"));
        if (!doc.RootElement.TryGetProperty("episodes", out var eps)) return res;

        var items = new List<(string season, JsonElement ep)>();
        if (eps.ValueKind == JsonValueKind.Object)
            foreach (var sn in eps.EnumerateObject()) foreach (var ep in sn.Value.EnumerateArray()) items.Add((sn.Name, ep));
        else if (eps.ValueKind == JsonValueKind.Array)
            foreach (var sn in eps.EnumerateArray()) foreach (var ep in sn.EnumerateArray()) items.Add((S(ep, "season"), ep));

        foreach (var (season, ep) in items)
        {
            var ext = S(ep, "container_extension"); if (ext == "") ext = "mp4";
            res.Add(new Channel
            {
                Name = $"S{season} · {S(ep, "title")}", Group = $"Saison {season}", Kind = Kind.Series,
                Url = $"{b}/series/{s.User}/{s.Pass}/{S(ep, "id")}.{ext}"
            });
        }
        return res;
    }
}
