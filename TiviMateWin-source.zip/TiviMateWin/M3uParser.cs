using System.Net.Http;
using System.Text;
namespace TiviMateWin;

// Lecture en flux (ligne par ligne) : fonctionne avec des fichiers > 200 Mo sans tout charger en RAM.
public static class M3uParser
{
    static readonly HttpClient Http = new() { Timeout = Timeout.InfiniteTimeSpan };

    public static string CachePath(string url) =>
        Path.Combine(AppSettings.CacheDir,
            Convert.ToHexString(System.Security.Cryptography.SHA1.HashData(Encoding.UTF8.GetBytes(url))) + ".m3u");

    public static async Task<List<Channel>> LoadAsync(string urlOrPath, bool force, IProgress<string> p, CancellationToken ct = default)
    {
        string file;
        if (System.IO.File.Exists(urlOrPath)) file = urlOrPath;
        else
        {
            file = CachePath(urlOrPath);
            if (force || !System.IO.File.Exists(file))
            {
                Directory.CreateDirectory(AppSettings.CacheDir);
                var tmp = file + ".part";
                using var req = new HttpRequestMessage(HttpMethod.Get, urlOrPath);
                req.Headers.UserAgent.ParseAdd("VLC/3.0.20 LibVLC/3.0.20");
                using var resp = await Http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);
                resp.EnsureSuccessStatusCode();
                long total = resp.Content.Headers.ContentLength ?? -1;
                using (var src = await resp.Content.ReadAsStreamAsync(ct))
                using (var dst = System.IO.File.Create(tmp))
                {
                    var buf = new byte[1 << 16]; long done = 0; int n;
                    while ((n = await src.ReadAsync(buf, ct)) > 0)
                    {
                        await dst.WriteAsync(buf.AsMemory(0, n), ct);
                        done += n;
                        p.Report($"Téléchargement… {done / 1048576} Mo" + (total > 0 ? $" / {total / 1048576} Mo" : ""));
                    }
                }
                System.IO.File.Move(tmp, file, true);
            }
        }
        return await Task.Run(() => Parse(file, p), ct);
    }

    static List<Channel> Parse(string file, IProgress<string> p)
    {
        var list = new List<Channel>();
        using var r = new StreamReader(file, Encoding.UTF8, true, 1 << 20);
        string? line; Channel? cur = null; int n = 0;
        while ((line = r.ReadLine()) != null)
        {
            if (line.StartsWith("#EXTINF", StringComparison.OrdinalIgnoreCase))
            {
                int q = line.LastIndexOf('"');
                int comma = line.IndexOf(',', q < 0 ? 0 : q);
                var g = Attr(line, "group-title");
                cur = new Channel
                {
                    Name = comma >= 0 ? line[(comma + 1)..].Trim() : "?",
                    Group = string.IsNullOrWhiteSpace(g) ? "Autres" : g,
                    Logo = Attr(line, "tvg-logo")
                };
            }
            else if (line.Length > 0 && line[0] != '#' && cur != null)
            {
                cur.Url = line.Trim();
                cur.Kind = Classify(cur);
                list.Add(cur); cur = null;
                if (++n % 50000 == 0) p.Report($"Analyse… {n:N0} éléments");
            }
        }
        return list;
    }

    static string? Attr(string line, string key)
    {
        int i = line.IndexOf(key + "=\"", StringComparison.OrdinalIgnoreCase);
        if (i < 0) return null;
        i += key.Length + 2;
        int j = line.IndexOf('"', i);
        return j < 0 ? null : line[i..j];
    }

    static Kind Classify(Channel c)
    {
        var u = c.Url; var g = c.Group;
        if (u.Contains("/movie/")) return Kind.Movie;
        if (u.Contains("/series/")) return Kind.Series;
        if (g.Contains("sport", StringComparison.OrdinalIgnoreCase) || g.Contains("bein", StringComparison.OrdinalIgnoreCase)) return Kind.Sport;
        if (g.Contains("vod", StringComparison.OrdinalIgnoreCase) || g.Contains("film", StringComparison.OrdinalIgnoreCase) || g.Contains("movie", StringComparison.OrdinalIgnoreCase)) return Kind.Movie;
        if (g.Contains("serie", StringComparison.OrdinalIgnoreCase)) return Kind.Series;
        return Kind.Live;
    }
}
