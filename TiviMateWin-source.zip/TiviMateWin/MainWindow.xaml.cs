using LibVLCSharp.Shared;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace TiviMateWin;

public partial class MainWindow : Window
{
    readonly AppSettings S = AppSettings.Load();
    List<Channel> All = new();
    Kind curKind = Kind.Live;
    LibVLC? libVlc;
    MediaPlayer? player;
    StalkerClient? stalker;
    bool fullscreen;

    public MainWindow()
    {
        InitializeComponent();
        Core.Initialize();
        ApplyBackground();
        Loaded += async (_, _) =>
        {
            libVlc = new LibVLC($"--network-caching={S.CachingMs}", "--file-caching=1000");
            player = new MediaPlayer(libVlc) { Volume = 80 };
            Video.MediaPlayer = player;
            if (S.ActiveSource == null) await OpenPlaylists();
            else await LoadAsync(false);
        };
        Closed += (_, _) => { player?.Stop(); player?.Dispose(); libVlc?.Dispose(); };
    }

    // ---------- Arrière-plan ----------
    void ApplyBackground()
    {
        string? path = S.Background;
        if (string.IsNullOrEmpty(path) || !System.IO.File.Exists(path))
        {
            var local = System.IO.Path.Combine(AppContext.BaseDirectory, "background.jpg");
            path = System.IO.File.Exists(local) ? local : null;
        }
        if (path == null) { BgImage.Source = null; return; }
        var bmp = new BitmapImage();
        bmp.BeginInit(); bmp.CacheOption = BitmapCacheOption.OnLoad; bmp.UriSource = new Uri(path); bmp.EndInit();
        BgImage.Source = bmp;
    }

    // ---------- Chargement des listes ----------
    async Task LoadAsync(bool force)
    {
        var src = S.ActiveSource;
        if (src == null) return;
        var prog = new Progress<string>(t => HomeStatus.Text = t);
        try
        {
            HomeStatus.Text = "Chargement…";
            stalker = null;
            List<Channel> res;
            switch (src.Type)
            {
                case SourceType.M3U: res = await M3uParser.LoadAsync(src.Url, force, prog); break;
                case SourceType.Xtream: res = await XtreamClient.LoadAsync(src, prog); break;
                default: stalker = new StalkerClient(src); res = await stalker.LoadAsync(prog); break;
            }
            All = res;
            HomeStatus.Text = $"{src.Name} : {All.Count:N0} éléments chargés";
        }
        catch (Exception ex) { HomeStatus.Text = "Erreur : " + ex.Message; }
    }

    async Task OpenPlaylists()
    {
        var w = new PlaylistWindow(S) { Owner = this };
        if (w.ShowDialog() == true && w.Changed) await LoadAsync(false);
    }

    // ---------- Accueil ----------
    void Live_Click(object s, RoutedEventArgs e) => OpenSection(Kind.Live, "En direct");
    void Movies_Click(object s, RoutedEventArgs e) => OpenSection(Kind.Movie, "Films");
    void Series_Click(object s, RoutedEventArgs e) => OpenSection(Kind.Series, "Séries");
    void Sports_Click(object s, RoutedEventArgs e) => OpenSection(Kind.Sport, "Sports");
    async void Playlists_Click(object s, RoutedEventArgs e) => await OpenPlaylists();
    async void Reload_Click(object s, RoutedEventArgs e) => await LoadAsync(true);
    void Exit_Click(object s, RoutedEventArgs e) => Close();
    void Settings_Click(object s, RoutedEventArgs e)
    {
        new SettingsWindow(S) { Owner = this }.ShowDialog();
        ApplyBackground();
    }

    void OpenSection(Kind k, string title)
    {
        if (All.Count == 0) { HomeStatus.Text = "Aucune liste chargée : utilisez « Modifier la liste de lecture »."; return; }
        curKind = k; SectionTitle.Text = title; SearchBox.Text = "";
        var groups = All.Where(c => c.Kind == k).Select(c => c.Group).Distinct().OrderBy(g => g).ToList();
        groups.Insert(0, "Tous");
        GroupList.ItemsSource = groups;
        GroupList.SelectedIndex = 0;
        HomePanel.Visibility = Visibility.Collapsed;
        BrowsePanel.Visibility = Visibility.Visible;
    }

    void Back_Click(object? s, RoutedEventArgs? e)
    {
        BrowsePanel.Visibility = Visibility.Collapsed;
        HomePanel.Visibility = Visibility.Visible;
    }

    // ---------- Liste ----------
    void Refilter()
    {
        var q = SearchBox.Text.Trim();
        var g = GroupList.SelectedItem as string;
        ChannelList.ItemsSource = All.Where(c => c.Kind == curKind
            && (g == null || g == "Tous" || c.Group == g)
            && (q.Length == 0 || c.Name.Contains(q, StringComparison.OrdinalIgnoreCase)))
            .Take(50000).ToList();
    }
    void Group_Changed(object s, SelectionChangedEventArgs e) => Refilter();
    void Search_Changed(object s, TextChangedEventArgs e) { if (IsLoaded && BrowsePanel.Visibility == Visibility.Visible) Refilter(); }
    void Channel_DoubleClick(object s, MouseButtonEventArgs e) { if (ChannelList.SelectedItem is Channel c) Play(c); }
    void Channel_KeyDown(object s, KeyEventArgs e) { if (e.Key == Key.Enter && ChannelList.SelectedItem is Channel c) Play(c); }

    // ---------- Lecture ----------
    async void Play(Channel c)
    {
        try
        {
            if (c.Kind == Kind.Series && c.SeriesId != null && S.ActiveSource != null)
            {
                NowPlaying.Text = "Chargement des épisodes…";
                ChannelList.ItemsSource = await XtreamClient.EpisodesAsync(S.ActiveSource, c.SeriesId);
                NowPlaying.Text = c.Name;
                return;
            }
            string url = c.Url;
            if (c.Cmd != null && stalker != null) url = await stalker.ResolveAsync(c.Cmd);
            if (libVlc == null || player == null) return;
            player.Play(new Media(libVlc, url, FromType.FromLocation));
            NowPlaying.Text = c.Name;
        }
        catch (Exception ex) { NowPlaying.Text = "Erreur : " + ex.Message; }
    }

    void Stop_Click(object s, RoutedEventArgs e) => player?.Stop();
    void Vol_Changed(object s, RoutedPropertyChangedEventArgs<double> e) { if (player != null) player.Volume = (int)e.NewValue; }
    void Fullscreen_Click(object s, RoutedEventArgs e) => ToggleFullscreen();

    void ToggleFullscreen()
    {
        fullscreen = !fullscreen;
        TopBar.Visibility = fullscreen ? Visibility.Collapsed : Visibility.Visible;
        ColA.Width = new GridLength(fullscreen ? 0 : 240);
        ColB.Width = new GridLength(fullscreen ? 0 : 380);
        if (fullscreen) { WindowState = WindowState.Normal; WindowStyle = WindowStyle.None; WindowState = WindowState.Maximized; }
        else { WindowStyle = WindowStyle.SingleBorderWindow; WindowState = WindowState.Normal; }
    }

    void Window_KeyDown(object s, KeyEventArgs e)
    {
        if (e.Key == Key.F11) ToggleFullscreen();
        else if (e.Key == Key.Escape)
        {
            if (fullscreen) ToggleFullscreen();
            else if (BrowsePanel.Visibility == Visibility.Visible) Back_Click(null, null);
        }
        else if (e.Key == Key.Space && BrowsePanel.Visibility == Visibility.Visible && player != null && Keyboard.FocusedElement is not TextBox)
            player.Pause();
    }
}
